#include <stdio.h>
#include <stdlib.h>
#include "program.h"

#ifdef WIN32
#include <io.h>
#include <fcntl.h>
#endif

int main(int argc, char *argv[])
{
  int32_t workSize[3] = {1920/64, 1080/40, 1};

  int32_t *outputs = (int32_t *)malloc(1920*1080*4);
  float inputs[8] = {1920, 1080, 0,0,0,0,0,0};

  ispc::runner_main(workSize, *((ispc::inputs*)inputs), *((ispc::outputs*)outputs));

  fprintf(stdout, "P7\nWIDTH 1920\nHEIGHT 1080\nDEPTH 4\nMAXVAL 255\nTUPLTYPE RGB_ALPHA\nENDHDR\n");
  fwrite((void*)outputs, 4, 1920*1080, stdout);

  free(outputs);
    
  return 0;
}
