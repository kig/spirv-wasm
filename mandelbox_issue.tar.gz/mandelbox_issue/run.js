Module.onRuntimeInitialized = function(){ 
    const width = 1920, height = 1080;
    const localSizeX = 64, localSizeY = 40;
    const numWorkGroupsX = width / localSizeX;
    const numWorkGroupsY = height / localSizeY;
    const numWorkGroupsZ =  1;

    const inputPtr = Module._malloc(8*4); // The shader takes an 8-float SSBO as input.
    const outputPtr = Module._malloc(width*height*4); // And writes to a 8-bit RGBA image buffer.

    const input = new Float32Array(Module.wasmMemory.buffer, inputPtr, 8);
    input.set([width, height, 0, 0, 0, 0, 0, 0]);
    
    console.time('compute');
    Module._run(numWorkGroupsX, numWorkGroupsY, numWorkGroupsZ, inputPtr, outputPtr);
    console.timeEnd('compute');

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    const id = ctx.createImageData(width, height);
    id.data.set(new Uint8Array(Module.wasmMemory.buffer, outputPtr, id.data.byteLength));
    ctx.putImageData(id, 0, 0);
    document.body.append(canvas);
};