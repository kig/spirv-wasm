#include <stdio.h>
#include <stdlib.h>
#include "program.h"
#include "emscripten.h"

EMSCRIPTEN_KEEPALIVE extern "C" 
int run(int w, int h, int d, ispc::inputs *inputs, ispc::outputs *outputs) {
  workSize[0] = w;
  workSize[1] = h;
  workSize[2] = d;
  ispc::runner_main(workSize, *inputs, *outputs);
  return (int)(outputs->outputData);
}

int main(int argc, char *argv[])
{
    return 0;
}
