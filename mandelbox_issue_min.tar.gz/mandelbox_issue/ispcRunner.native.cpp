#include <stdio.h>
#include <stdlib.h>
#include "program.h"

int main(int argc, char *argv[])
{
  int32_t workSize[3] = {1, 1, 1};

  int32_t w = 4, h = 1;

  uint8_t *outputs = (uint8_t *)malloc(w*h*4);
  float inputs[8] = {1920, 1080, 0,0,0,0,0,0};

  ispc::runner_main(workSize, *((ispc::inputs*)inputs), *((ispc::outputs*)outputs));

  // for (int i=0; i < w*h*4; i++) {
  //   fprintf(stdout, "%d\t", outputs[i]);
  //   if (i%4 == 3) fprintf(stdout, "\n");
  // }

  free(outputs);
    
  return 0;
}
