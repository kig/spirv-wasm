Module.onRuntimeInitialized = function(){ 
    const width = 4, height = 1;
    const localSizeX = 4, localSizeY = 1;
    const numWorkGroupsX = width / localSizeX;
    const numWorkGroupsY = height / localSizeY;
    const numWorkGroupsZ =  1;

    const inputPtr = Module._malloc(8*4); // The shader takes an 8-float SSBO as input.
    const outputPtr = Module._malloc(width*height*4); // And writes to a 8-bit RGBA image buffer.

    const input = new Float32Array(Module.wasmMemory.buffer, inputPtr, 8);
    input.set([1920, 1080, 0, 0, 0, 0, 0, 0]);
    
    console.time('compute');
    Module._run(numWorkGroupsX, numWorkGroupsY, numWorkGroupsZ, inputPtr, outputPtr);
    console.timeEnd('compute');

    // const u8 = new Uint8Array(Module.wasmMemory.buffer, outputPtr, width*height*4);
    // let s = '';
    // u8.forEach((v,i) => {
    //     s += v + '\t';
    //     if (i % 4 === 3) s += "\n";
    // });
    // console.log(s);
};